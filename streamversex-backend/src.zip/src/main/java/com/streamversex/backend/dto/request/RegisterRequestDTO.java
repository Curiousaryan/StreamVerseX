package com.streamversex.backend.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class RegisterRequestDTO {
	
	@NotBlank(message="Name is required")
	private String name;
	
	@NotBlank(message="Email is required")
	@Email(message="Email must be valid")
	private String email;
	
	@NotBlank(message="password is required")
	@Size(min=8, message="password must be at least 8 characters")
	private String password;
	
	

}
