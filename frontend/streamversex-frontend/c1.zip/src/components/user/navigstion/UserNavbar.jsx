import { NavLink, useNavigate } from "react-router-dom";
import {
  Search,
  Bell,
  UserRound,
  LogOut,
} from "lucide-react";

import { ROUTES } from "../../../routes/routeConstants";

function UserNavbar() {
  const navigate = useNavigate();

  const navLinks = [
    { name: "Home", path: ROUTES.HOME },
    { name: "Movies", path: ROUTES.MOVIES },
    { name: "TV Shows", path: ROUTES.TV_SHOWS },
    { name: "Anime", path: ROUTES.ANIME },
    { name: "Watchlist", path: ROUTES.WATCHLIST },
  ];

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate(ROUTES.LOGIN, { replace: true });
  };

  return (
    <header className="sticky top-0 z-50 bg-black/95 border-b border-white/10">
      <div className="max-w-[1600px] mx-auto h-16 px-6 flex items-center">

        {/* Logo */}
        <NavLink
          to={ROUTES.HOME}
          className="text-2xl font-bold text-red-600 mr-10"
        >
          StreamVerseX
        </NavLink>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `text-sm font-medium transition ${
                  isActive
                    ? "text-white"
                    : "text-gray-400 hover:text-white"
                }`
              }
            >
              {link.name}
            </NavLink>
          ))}
        </nav>

        {/* Right Navigation */}
        <div className="ml-auto flex items-center gap-5">

          <button
            type="button"
            onClick={() => navigate(ROUTES.SEARCH)}
            className="text-gray-300 hover:text-white transition"
            aria-label="Search"
          >
            <Search size={21} />
          </button>

          <button
            type="button"
            onClick={() => navigate(ROUTES.NOTIFICATIONS)}
            className="text-gray-300 hover:text-white transition"
            aria-label="Notifications"
          >
            <Bell size={21} />
          </button>

          <button
            type="button"
            onClick={() => navigate(ROUTES.PROFILE)}
            className="text-gray-300 hover:text-white transition"
            aria-label="Profile"
          >
            <UserRound size={21} />
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="text-gray-300 hover:text-red-500 transition"
            aria-label="Logout"
          >
            <LogOut size={21} />
          </button>

        </div>
      </div>
    </header>
  );
}

export default UserNavbar;