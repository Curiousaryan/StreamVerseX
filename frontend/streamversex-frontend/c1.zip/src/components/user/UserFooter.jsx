// src/components/user/UserFooter.jsx

function UserFooter() {
  return null;
}

export default UserFooter;