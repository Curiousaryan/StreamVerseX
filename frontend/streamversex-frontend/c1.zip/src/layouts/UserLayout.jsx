import { Outlet } from "react-router-dom";

import UserNavbar from "../components/user/navigation/UserNavbar";
import UserFooter from "../components/user/UserFooter";

function UserLayout() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <UserNavbar />

      <main className="flex-1">
        <Outlet />
      </main>

      <UserFooter />
    </div>
  );
}

export default UserLayout;
// import { Outlet } from "react-router-dom";

// function UserLayout() {
//   return (
//     <>
//       {/* Topbar */}

//       {/* Sidebar */}

//       <main>
//         <Outlet />
//       </main>
//     </>
//   );
// }

// export default UserLayout;