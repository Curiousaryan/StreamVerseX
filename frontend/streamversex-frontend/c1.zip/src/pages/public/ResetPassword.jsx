function ResetPassword(){
    return(<>
    
    <h1>ResetPassword Page</h1>
    
    </>);
}

export default ResetPassword;